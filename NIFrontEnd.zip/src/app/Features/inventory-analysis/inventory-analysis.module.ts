import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventoryAnalysisRoutingModule } from './inventory-analysis-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InventoryAnalysisRoutingModule
  ]
})
export class InventoryAnalysisModule { }
