import { ChatlistunicodePipe } from './chatlistunicode.pipe';

describe('ChatlistunicodePipe', () => {
  it('create an instance', () => {
    const pipe = new ChatlistunicodePipe();
    expect(pipe).toBeTruthy();
  });
});
