import { ConvertLeftsidetextHtmlPipe } from './convert-leftsidetext-html.pipe';

describe('ConvertLeftsidetextHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertLeftsidetextHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
