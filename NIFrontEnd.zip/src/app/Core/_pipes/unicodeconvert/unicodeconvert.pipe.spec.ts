import { UnicodeconvertPipe } from './unicodeconvert.pipe';

describe('UnicodeconvertPipe', () => {
  it('create an instance', () => {
    const pipe = new UnicodeconvertPipe();
    expect(pipe).toBeTruthy();
  });
});
