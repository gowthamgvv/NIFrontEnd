import { TimeconvertionPipe } from './timeconvertion.pipe';

describe('TimeconvertionPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeconvertionPipe();
    expect(pipe).toBeTruthy();
  });
});
