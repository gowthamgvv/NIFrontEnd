import { AlphaFilterPipe } from './alpha-filter.pipe';

describe('AlphaFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AlphaFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
