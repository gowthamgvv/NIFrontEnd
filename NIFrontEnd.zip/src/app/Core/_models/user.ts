export class usersPwdModel {
    constructor(
      public Dealer_Id: number,
      public Old_pswrd: any,
      public New_pswrd: any,
  
    ) { }
  }