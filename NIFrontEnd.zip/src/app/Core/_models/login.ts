export class LoginModel {
  constructor(
      public email: string,
      public Password: string
  ){}
}
