export const environment = {
  production: true,
  //apiUrl: 'http://demoapi.nilocal.com/api/',
  apiUrl:'http://devapi.netimpact.com/api/',
  apiMWUrl: 'http://apimw.azaz.com/api/',
   dealerInfo:[],
  //apiUrl: 'http://niapi.local.com/api/'
};
