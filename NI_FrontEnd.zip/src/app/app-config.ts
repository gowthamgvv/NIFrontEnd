export const config={
    dealerInfo:[]
}