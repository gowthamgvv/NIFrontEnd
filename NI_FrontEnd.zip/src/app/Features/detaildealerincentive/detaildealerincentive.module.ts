import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';


import { DetaildealerincentiveRoutingModule } from './detaildealerincentive-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DetaildealerincentiveRoutingModule
  ]
})
export class DetaildealerincentiveModule { }
