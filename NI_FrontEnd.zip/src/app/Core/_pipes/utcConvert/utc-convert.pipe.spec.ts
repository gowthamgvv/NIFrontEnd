import { UtcConvertPipe } from './utc-convert.pipe';

describe('UtcConvertPipe', () => {
  it('create an instance', () => {
    const pipe = new UtcConvertPipe();
    expect(pipe).toBeTruthy();
  });
});
