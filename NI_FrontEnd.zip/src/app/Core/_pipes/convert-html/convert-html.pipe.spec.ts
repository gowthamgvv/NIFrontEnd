import { ConvertHtmlPipe } from './convert-html.pipe';

describe('ConvertHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
